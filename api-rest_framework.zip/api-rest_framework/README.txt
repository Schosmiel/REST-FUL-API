```bash
$ # Get the code
$ git clone https://github.com/schosmiel/
$
$ cd material-dashboard-django
$
$ # Virtualenv modules installation (Unix based systems)
$ virtualenv env
$ source env/bin/activate
$
$ # Virtualenv modules installation (Windows based systems)
$ # pip install venv env
$ # .\env\Scripts\activate
$
$ # Install modules -postgresql
$ pip3 install -r requirements.txt
$
$ # Create tables
$ python manage.py makemigrations
$ python manage.py migrate
$
$ # Start the application (development mode)
$ python manage.py runserver # default port 8000
$
$ # 
$ # python manage.py runserver 0.0.0.0:<your_port>
$
$ # Access the web app in browser: http://127.0.0.1:8000/
``'

<br />

## Documentation

<br />

## File Structure
Within the download you'll find the following directories and files:

```bash
< PROJECT ROOT >
   |
   |-- restfulapicrud/
   |    |
   |    |-- apicrud/                        # A simple app that serve HTML files
   |    |    |-- admin.py                  # Serve HTML pages for authenticated users
   |    |    |-- app.py                     # Define some super simple routes  
   |    |    |--models.py
   |    |    |--serializer.py               # A simple app that seralisations
   |    |    |-- test.py                     # Serve HTML pages for authenticated users
   |    |    |-- view.py 
   |    |    |-- test.py                     # Serve HTML pages for authenticated users
   |    |    |-- viewsets.py 
   |    |    |-- migrations 
   |    |--restfulapicrud                  # Handles auth routes
   |    |    |-- asgi.py 
   |    |    |-- router.py                  # Serve HTML pages for authenticated users
   |    |    |-- setings.py 
   |    |    |-- urls.py                     # Define authentication routes  
   |    |    |-- wsgi.py                    # Handles login and registration   
   |    |    |
   |    |-- requirements.txt             # Development modules - postgresql storage
   |    |
   |    | -- manage.py                    # Inject Configuration via Environment
   |    |                                       # Start the app - Django default start script
   |--README.txt
   |-- .env
   |-- ************************************************************************
```