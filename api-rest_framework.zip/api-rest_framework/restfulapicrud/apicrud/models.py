from django.db import models

# Create your models here.

class Client(models.Model):
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    refgps = models.CharField(max_length=15)
    telephone = models.CharField(max_length=15)
    
 
class Livreur(models.Model):
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    mdp = models.CharField(max_length=25)
    adresses = models.CharField(max_length=100)
 
        
class Produits(models.Model):
    name = models.CharField(max_length=255)
    masse = models.IntegerField()
    qte = models.IntegerField() 
    date_add = models.DateTimeField(auto_now_add=True)
    price = models.DecimalField(max_digits=15, decimal_places=2)
    image = models.ImageField(upload_to='product')
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    livreur = models.ForeignKey(Livreur, on_delete=models.CASCADE)
    
"""
    @property
    def get_discount(self):
        return "%.2f"%(float(self.price)*0.5)
"""

    
      
class Livraison(models.Model):
    heure_livraison = models.DateTimeField()
    lieu = models.CharField(max_length=125)
    montant = models.IntegerField()
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    livreur = models.ForeignKey(Livreur, on_delete=models.CASCADE)

    
    
class Administrateur(models.Model):
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    mdp = models.CharField(max_length=25)
    livreur = models.ForeignKey(Livreur, on_delete=models.CASCADE)
    produits = models.ForeignKey(Produits, on_delete=models.CASCADE)
