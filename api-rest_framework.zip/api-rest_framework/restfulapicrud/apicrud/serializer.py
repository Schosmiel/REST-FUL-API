from rest_framework import serializers
from .models import *

class ClientSerializer(serializers.ModelSerializer):
    class Meta:
        model = Client
        fields='__all__'


class LivreurSerializer(serializers.ModelSerializer):
    class Meta:
        model = Livreur
        fields='__all__'



class ProduitsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Produits
        fields='__all__'
        
class LivraisonSerializer(serializers.ModelSerializer):
    class Meta:
        model = Livraison
        fields='__all__'
