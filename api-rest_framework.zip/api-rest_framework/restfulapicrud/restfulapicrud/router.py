from apicrud.viewsets import *
from rest_framework import routers


router=routers.DefaultRouter()
router.register('client', ClientViewsets)
router.register('livreur', LiveurViewsets)
router.register('produits', ProduitsViewsets)
router.register('livraison', LivraisonViewsets)
